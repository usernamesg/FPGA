# Basys3 MM:SS Stopwatch (minimalized)

## Vivado Sources (7 files)
- top.v — Top-level (`clk`, `reset`, `btn[2:0]`, `seg[7:0]`, `an[3:0]`)
- button_debounce10ms.v — button synchronization and 10ms debounce
- main_controller.v — 4-state FSM, MM:SS counter, idle/animation/blink timing
- tick_generator.v — FND scan tick (1kHz)
- fnd_controller.v — FND module connections
- fnd_digit_select.v — digit scanning
- fnd_digit_display.v — numeral patterns, rotating segment, DP

**Not used:** `bin2bcd4digit.v`, SW inputs, LED outputs, old up/down/switch-read modes.

Button mapping: `btn[0]=btnL`, `btn[1]=btnC`, `btn[2]=btnR`. Separate `reset` is an active-high system reset. Pin assignments must match this top module. Basys3 7-seg signals are active-low; `seg[7]` controls DP. The separator DP is on AN2 (minute ones). The 4 digits show `MMSS`.

Reset -> IDLE 00:00. L starts, C pauses, R resets to IDLE. After 5s in PAUSED, circular outer segment animation runs until a button press. In ANIMATION: L resumes counting, C returns to PAUSED, R resets. DP blinks ON/OFF at 0.5s intervals (hidden in animation). At 59:59, time is held.

Internal counter continues from its fractional-second value after pause/resume. Clock enables instead of a new derived clock.

Set Vivado top module `top`, and use your Basys3 XDC mapping for `clk`, `reset`, `btn[2:0]`, `seg[7:0]`, `an[3:0]`.
