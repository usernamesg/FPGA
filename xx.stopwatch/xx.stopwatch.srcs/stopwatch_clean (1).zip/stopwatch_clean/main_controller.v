`timescale 1ns / 1ps
module main_controller #(
    parameter integer CLK_FREQ = 100_000_000
)(
    input clk, reset,
    input [2:0] btn, // {btnR, btnC, btnL}, debounced
    output [15:0] digits, // {min_tens, min_ones, sec_tens, sec_ones}
    output animation,
    output [2:0] anim_step,
    output dot_on
);
    localparam [1:0] IDLE=0, RUNNING=1, PAUSED=2, ANIMATION=3;
    localparam integer HALF_SEC = CLK_FREQ/2;
    localparam integer FIVE_SEC = 5*CLK_FREQ;
    localparam integer ANIM_INTERVAL = 15*CLK_FREQ/100;
    reg [1:0] state;
    reg [5:0] minutes, seconds;
    reg [31:0] sec_count, idle_count, anim_count, blink_count;
    reg [2:0] prev_btn, anim_index;
    reg blink_state;
    wire [2:0] pressed = btn & ~prev_btn;

    wire [3:0] mt = minutes / 10;
    wire [3:0] mo = minutes % 10;
    wire [3:0] st = seconds / 10;
    wire [3:0] so = seconds % 10;
    assign digits = {mt, mo, st, so};
    assign animation = (state == ANIMATION);
    assign anim_step = anim_index;
    assign dot_on = blink_state && !animation;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state <= IDLE;
            minutes <= 0; seconds <= 0;
            sec_count <= 0; idle_count <= 0;
            anim_count <= 0; anim_index <= 0;
            blink_count <= 0; blink_state <= 1'b1;
            prev_btn <= 0;
        end else begin
            prev_btn <= btn;
            if (blink_count == HALF_SEC-1) begin
                blink_count <= 0;
                blink_state <= ~blink_state;
            end else blink_count <= blink_count + 1'b1;

            // Priority: Reset > Pause > Start > periodic state logic
            if (pressed[2]) begin
                state <= IDLE;
                minutes <= 0; seconds <= 0;
                sec_count <= 0; idle_count <= 0;
                anim_count <= 0; anim_index <= 0;
            end else if (pressed[1]) begin
                if (state == RUNNING || state == ANIMATION)
                    state <= PAUSED;
                idle_count <= 0;
                anim_count <= 0; anim_index <= 0;
            end else if (pressed[0]) begin
                if (state != RUNNING && !(minutes == 59 && seconds == 59))
                    state <= RUNNING;
                else if (state == ANIMATION) state <= PAUSED;
                idle_count <= 0;
                anim_count <= 0; anim_index <= 0;
            end else begin
                case (state)
                    IDLE: begin idle_count <= 0; sec_count <= 0; end
                    RUNNING: begin
                        idle_count <= 0;
                        if (sec_count == CLK_FREQ-1) begin
                            sec_count <= 0;
                            if (seconds == 59) begin
                                if (minutes == 59) begin
                                    state <= PAUSED; // hold 59:59
                                end else begin
                                    seconds <= 0;
                                    minutes <= minutes + 1'b1;
                                end
                            end else seconds <= seconds + 1'b1;
                        end else sec_count <= sec_count + 1'b1;
                    end
                    PAUSED: begin
                        if (idle_count == FIVE_SEC-1) begin
                            idle_count <= 0;
                            anim_count <= 0; anim_index <= 0;
                            state <= ANIMATION;
                        end else idle_count <= idle_count + 1'b1;
                    end
                    ANIMATION: begin
                        if (anim_count == ANIM_INTERVAL-1) begin
                            anim_count <= 0;
                            anim_index <= (anim_index == 5) ? 0 : anim_index + 1'b1;
                        end else anim_count <= anim_count + 1'b1;
                    end
                    default: state <= IDLE;
                endcase
            end
        end
    end
endmodule
